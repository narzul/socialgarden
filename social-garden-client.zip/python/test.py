import socialgardenapi
import time
#i = 0



#print(socialgardenapi.streamExists("DeviceName"))

for x in range(0, 5):
    socialgardenapi.insertStream("DeviceName", "Beskrivelse",'{"Name":"light","Value":10}')
    time.sleep(0.2)
    socialgardenapi.insertStream("DeviceName", "Beskrivelse",'{"Name":"water","Value":20}')
    time.sleep(0.2)


#print(socialgardenapi.getAllDoc("DeviceName"))


print(socialgardenapi.getLastDoc("DeviceName"))
socialgardenapi.deleteStream("DeviceName")
