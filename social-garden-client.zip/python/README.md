# Social garden python API
## Introduction
The Social Garden python API, has been setup to send REST CRUD operations to the web service. Researchers can thus use this API in order to connecting devices and sensors to a central server.

This package can be imported into any other python package by downloading the package to the same folder.


##### Year - 2018 IT-University of Copenhagen, Denmark

See MongoDb for closer refrences  [MongoDb documentation]( https://docs.mongodb.com/manual/tutorial/query-documents/ )


## Installation guide
The API uses geocoder in order to find the coordinates of the device, based on IP.
```
git clone https://github.com/DenisCarriere/geocoder
```
Navigate to the geocoder folder and install package
```
cd geocoder
python setup.py install
```

### Insert document
Insert doc is used to insert a documen. It takes the following arguments. Furthermore the it adds a localtimestamp to the doc before inserting it to the database

```python
insertStream(DeviceName, Description, ListOfSensor)
insertStream("DeviceName", "Beskrivelse",'{"Name":"light","Value":10}')

```



### Example
All it takes to use socialgarden API is an Import.
see test.py for refrences

```python
import socialgardenapi

while true:
  insertNewStream("DeviceName", "Beskrivelse",'{"Name":"temp","Value":valFromTempSensor}')

  getDoc("DeviceName")
```


### Old.py
This file conains the old and very wrong implementation. At this point we used SSH. The file is currently used as a sketch of the implementation, while working socialgardenapi.py
