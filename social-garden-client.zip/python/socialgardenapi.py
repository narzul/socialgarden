import requests
import json
import datetime
import geocoder
import requests
import json
address = 'http://159.65.116.139:3000/devices/'
#address = 'http://localhost:3000/devices/'

#Check it stream exists in the database.
def streamExists(DeviceName):

    if getAllDoc(DeviceName) == []:
        print('False')
        return False
    print(getLastDoc(DeviceName))
    return True
    print('True')


def getAllDoc(DeviceName):
    headers = {
        'Accept': 'application/json',
    }
    response = requests.get(address+DeviceName+'', headers=headers)
    return response.json()

def getLastDoc(DeviceName):
    headers = {
        'Accept': 'application/json',
    }
    response = requests.get(address+DeviceName+'/one', headers=headers)
    return response.json()


def getDeviceSensor(DeviceName, Sensor):
    headers = {
        'Accept': 'application/json',
    }
    response = requests.get(address+DeviceName+'/'+Sensor, headers=headers)
    return response.json()

def insertStream(DeviceName,  Description, Sensor):
    headers = {
        'Content-Type': 'application/json',
    }
    g = geocoder.ip('me')
    data = '{"DeviceName": "'+DeviceName+'","TimeStamp" :"'+str(datetime.datetime.utcnow())+'","Description":"'+Description+'","Location":{ "Latitude":'+str(g.lat)+', "Longitude":'+str(g.lng)+' }, "Sensor" : '+Sensor+' } '
    response = requests.post(address, headers=headers, data=data)
    print("Doc inserted into " + str(address))
    print(data)


def deleteStream(DeviceName):
    #response = requests.delete(address+DeviceName)
    headers = {
        'Accept': 'application/json',
    }
    response = requests.get(address+DeviceName+'/delete', headers=headers)
    return response.json()
